﻿public record Document(string Title, string Content);
