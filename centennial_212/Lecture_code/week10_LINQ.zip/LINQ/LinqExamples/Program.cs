﻿// See https://aka.ms/new-console-template for more information

//LinqSamples.GenerateRange();

//SortingSamples.SortMultiple();
//SortingSamples.SortDescendingWithMethods();

//JoinSamples.InnerJoinWithMethods();

//GroupSamples.GroupingAndNestedObjects();

