﻿global using DataLib;
