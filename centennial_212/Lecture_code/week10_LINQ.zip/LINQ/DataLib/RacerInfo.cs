﻿namespace DataLib;

public record RacerInfo(int Year, int Postion, string FirstName, string LastName) {}
