﻿namespace DataLib;

public record Championship(int Year, string First, string Second, string Third);
