﻿namespace IMSLibrary
{
    public class Class1
    {

    }
}
