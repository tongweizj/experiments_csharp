﻿using IMSManager.Model;
using System;
using System.Windows;
using System.Windows.Controls;

namespace IMSManager
{
    /// <summary>
    /// Interaction logic for AddNewPolicyView.xaml
    /// </summary>
    public partial class AddNewPolicyView : UserControl
    {
        public AddNewPolicyView()
        {
            InitializeComponent();
        }
    }
}
