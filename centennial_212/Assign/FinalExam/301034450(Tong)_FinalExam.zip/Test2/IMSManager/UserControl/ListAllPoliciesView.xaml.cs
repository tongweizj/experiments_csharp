﻿using IMSManager.Model;
using IMSManager.ViewModels;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace IMSManager
{
    /// <summary>
    /// Interaction logic for ListAllPoliciesView.xaml
    /// </summary>
    public partial class ListAllPoliciesView : UserControl
    {
        public ListAllPoliciesView()
        {
            InitializeComponent();
        }
    }
}
