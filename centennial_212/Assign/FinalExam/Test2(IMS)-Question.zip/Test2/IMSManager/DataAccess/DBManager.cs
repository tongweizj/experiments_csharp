﻿using IMSLibrary.Models;
using IMSManager.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IMSManager.DataAccess
{
    public class DBManager
    {
        ImsContext db = new ImsContext();

        public List<AgentComboBoxModel> GetAgents()
        {
            List<AgentComboBoxModel> agentList = new List<AgentComboBoxModel>();
            
            // finish the method

            return agentList;
        }

        public List<PolicyDetails> GetPolicyDetails(string agentId)
        {
            List<PolicyDetails> insuranceList = new List<PolicyDetails>();
           
            // finish the method

            return insuranceList;
        }

        public List<ProductComboBoxModel> GetProducts()
        {
            List<ProductComboBoxModel> productList = new List<ProductComboBoxModel>();
           
            // finish the method 

            return productList;
        }

        public void AddItem(InsurancePolicy newPolicy)
        { 
            //finish the method 
        }
    }
}
