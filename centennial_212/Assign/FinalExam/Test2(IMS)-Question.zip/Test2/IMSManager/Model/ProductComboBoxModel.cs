﻿
namespace IMSManager.Model
{
    public class ProductComboBoxModel
    {
        public string Code { get; set; }

        public string Name { get; set; }
    }
}
