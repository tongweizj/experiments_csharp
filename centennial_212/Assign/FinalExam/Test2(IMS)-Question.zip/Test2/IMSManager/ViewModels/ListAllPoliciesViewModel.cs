﻿using IMSManager.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace IMSManager.ViewModels
{
    public class ListAllPoliciesViewModel: ViewModelBase
    {
       // finish the class 
    }
}
